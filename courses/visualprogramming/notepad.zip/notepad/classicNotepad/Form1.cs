﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace classicNotepad
{
    public partial class Form1 : Form
    {
        private string fileName;
        public Form1()
        {
            this.fileName = "Untitled document";
            InitializeComponent();
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog fDialog = new SaveFileDialog();
                fDialog.ShowDialog();
                File.WriteAllText(fDialog.FileName, richTextBox1.Text);
                this.Text = this.Text.Replace("*", "");
            }catch(Exception ex){
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = fileName;
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            this.Text = fileName + "*";
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(this.Text.Contains("*")){            
                DialogResult res = MessageBox.Show("Are you sure to close without saving",
                    "Save document",
                    MessageBoxButtons.YesNo);
                if (res == DialogResult.Yes)
                {

                    e.Cancel = false;
                }
                else {
                    e.Cancel = true;
                }             
            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog fDialog = new OpenFileDialog();
                fDialog.ShowDialog();
                richTextBox1.Text = File.ReadAllText(fDialog.FileName);
                this.fileName = this.Text = fDialog.FileName;
            }catch(Exception ex){
                MessageBox.Show(ex.Message);
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Copy();
        }

        private void largeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Font = new Font(richTextBox1.Font.Name,
                                30,
                                richTextBox1.Font.Style);
            

        }
    }
}
