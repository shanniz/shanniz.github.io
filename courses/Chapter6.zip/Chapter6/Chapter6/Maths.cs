﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class Maths
    {
        public int add(int a, int b) {
            return a + b;
        }
        public int power(int num, int p)
        {
            int res = 1;
            while ((res *= num) >0 && p-- >1 ) ;

            return res;
        }
    }
}
