﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Chapter6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            /*
            string connectionString = "server=localhost\\SQLExpress;integrated Security=true;";

            using (SqlConnection _con = new SqlConnection(connectionString))
            {
                _con.Open();
                //string queryStatement = "SELECT * FROM dbo.Customers ORDER BY CustomerID";
                string queryStatement = "show databases;";
                DataTable databases = _con.GetSchema("Databases");
                foreach (DataRow database in databases.Rows)
                {
                    String databaseName = database.Field<String>("database_name");
                    short dbID = database.Field<short>("dbid");
                    DateTime creationDate = database.Field<DateTime>("create_date");
                }

                using (SqlCommand _cmd = new SqlCommand(queryStatement, _con))
                {
                    DataTable customerTable = new DataTable("Top5Customers");

                    SqlDataAdapter _dap = new SqlDataAdapter(_cmd);

                    _dap.Fill(customerTable);
                    _con.Close();

                }
            }
            */

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }




        private void button2_Click(object sender, EventArgs e)
        {

            Maths m = new Maths();

            int sum =  m.add(
                 Convert.ToInt32(textBox1.Text), 
                 Convert.ToInt32(textBox2.Text)
                 );
            
            textBox3.Text = sum.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Maths m = new Maths();

            int pow = m.power(
                Convert.ToInt32(textBox1.Text),
                Convert.ToInt32(textBox2.Text)
                );

            textBox3.Text = pow.ToString();
        }
    }
}
