﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class Building
    {
        public int Floors; // number of floors
        public int Area; // total square footage of building
        public int Occupants; // number of occupants

        // Display the area per person.
        public string AreaPerPerson()
        {
            return  " " + Area / Occupants + " area per person";
            
        }

    }
}
